addEventListener('fetch', event => {
  if (event.request.url.endsWith("/links"))
    event.respondWith(getLinks(event.request))
  else
    event.respondWith(getPage(event.request))
})

/**
 * Return the JSONified links to show
 * @param {Request} request
 */
async function getLinks(request) {
  let headers = {
    "Content-Type": "application/json"
  }
  let response = new Response(JSON.stringify(links), { status: 200, headers: headers })
  return response
}

/**
 * Return the HTML page for this set of links
 * @param {Request} request
 */
async function getPage(request) {
  let res = await fetch("https://static-links-page.signalnerve.workers.dev")
  return new HTMLRewriter()
    .on("div#links", new LinksTransformer(links))
    .on("div#profile", new ProfileTransformer())
    .on("img#avatar", new AvatarTransformer())
    .on("h1#name", new NameTransformer())
    .on("title", new TitleTransformer())
    .on("div#social", new SocialTransformer())
    .transform(res)
}

// HTML Transformers for landing page
class LinksTransformer {
  constructor(obj) {
    this.links = obj
  }

  element(element) {
    let content = ""
    links.forEach(item => {
      content += "<a href=\"" + item.url + "\">" + item.name + "</a>"
    });
    element.setInnerContent(content, { html: true })
  }
}

class ProfileTransformer {
  element(element) {
    element.removeAttribute("style")
  }
}

class AvatarTransformer {
  element(element) {
    element.setAttribute("src", profilePic)
  }
}

class NameTransformer {
  element(element) {
    element.setInnerContent("Vivek Patel")
  }
}

class TitleTransformer {
  element(element) {
    element.setInnerContent("Vivek Patel")
  }
}

class SocialTransformer {
  async element(element) {
    element.removeAttribute("style")
    let svg = await fetch("https://simpleicons.org/icons/instagram.svg")
    let html = `<a href=\"https://instagram.com/vivekstagram\"> ${await svg.text()} </a>`
    element.setInnerContent(html, { html: true })
  }
}


// A long-winded profile photo link
const profilePic = "https://media-exp1.licdn.com/dms/image/C5603AQEomE6quGS0lQ/profile-displayphoto-shrink_400_400/0?e=1607558400&v=beta&t=2zPm8Wsq42cJR159rI_Axk5STN64-OPf42pD4d5AV7g"


// Here's some links to work with
const links = [
  {
    "name": "Good food videos",
    "url": "https://www.youtube.com/c/bingingwithbabish"
  },
  {
    "name": "Kawhi Leonard is a gem",
    "url": "https://www.youtube.com/watch?v=zIwh0njInPk"
  },
  {
    "name": "Hire me :)",
    "url": "https://vivkpatl.github.io"
  }
]